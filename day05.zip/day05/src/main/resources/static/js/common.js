window.addEventListener("DOMContentLoaded", function(){
    const userId = document.getElementsByName('userId');
    console.log(userId);

});