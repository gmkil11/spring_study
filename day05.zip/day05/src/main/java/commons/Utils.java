package commons;


public class Utils {
    public String toUpper(String str) {
        return str.toUpperCase();
    }
}
