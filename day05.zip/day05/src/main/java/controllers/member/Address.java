package controllers.member;

import lombok.Data;

@Data
public class Address {
    private String zipcode;
    private String address;
    private String addressSub;
}
